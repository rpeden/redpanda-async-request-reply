from kafka import KafkaProducer, KafkaConsumer
producer = KafkaProducer(
    bootstrap_servers = "localhost:9092"
)

producer.send("image-request", b"test22")