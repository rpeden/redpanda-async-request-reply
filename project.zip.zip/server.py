import asyncio
import os 

from fastapi import FastAPI, WebSocket, UploadFile, File
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from aiokafka import AIOKafkaProducer, AIOKafkaConsumer




app = FastAPI()
kafka_server = "localhost:9092"  # Replace with your Redpanda server address
request_topic = "image-request"
response_topic = "image-response"


# from kafka import KafkaProducer, KafkaConsumer
# producer = KafkaProducer(
#     bootstrap_servers = "localhost:9092"
# )


# consumer = KafkaConsumer(
#     request_topic,
#     bootstrap_servers = "localhost:9092",
#     group_id = "image-desaturate-group"
# )

# producer.send(request_topic, b"test")
# # for msg in consumer:
# #     print(msg.value)

# Kafka Producer for sending messages
async def send_to_kafka(topic, message):
    producer = AIOKafkaProducer(bootstrap_servers=[kafka_server])
    await producer.start()
    try:
        await producer.send_and_wait(topic, message.encode('utf-8'))
    finally:
        await producer.stop()

# Kafka Consumer for receiving messages
async def consume_from_kafka(topic, callback):
    print(f"Consuming from {topic}")
    consumer = AIOKafkaConsumer(
        topic,
        bootstrap_servers=kafka_server,
        auto_offset_reset="earliest",
        enable_auto_commit=False,
        group_id="image-desaturate-group"
    )
    await consumer.start()
    print("Consumer started")
    try:
        async for msg in consumer:
            print(f"Received message: {msg.value.decode('utf-8')}")
            await callback(msg)
    finally:
        await consumer.stop()

# Mount the static directory to serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Redirect root to the static index.html
@app.get("/")
async def read_index():
    return FileResponse('static/index.html')

# Endpoint to upload an image
@app.post("/upload-image/")
async def upload_image(file: UploadFile = File(...)):
    # Save the file (implement your own logic)
    current_dir = os.path.dirname(os.path.realpath(__file__))
    file_location = os.path.join(current_dir, f"static/images/{file.filename}")
    print(f"Saving file to {file_location}")
    with open(file_location, "wb") as file_object:
        file_object.write(await file.read())
    # Send filename to Kafka
    await send_to_kafka(request_topic, file.filename)
    return {"filename": file.filename}

# WebSocket endpoint
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    async def send_message_to_websocket(msg):
        await websocket.send_text(msg.value.decode('utf-8'))

    # Start consuming
    asyncio.create_task(consume_from_kafka(request_topic, send_message_to_websocket))

    # Keep the connection open
    while True:
        await asyncio.sleep(10)

# Start the server
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app)